AJMAL CYBER SCANNER PRO — READY PROJECT FILES

Is ZIP mein kya hai?
- index.html: mobile-friendly clickable app interface
- README_HINGLISH.txt: use karne ke steps

PHONE PAR PREVIEW:
1. ZIP download karke Files/Downloads mein jao.
2. ZIP ko Extract karo.
3. index.html ko Chrome/browser mein open karo.
4. Dashboard ke buttons tap karke demo screens check karo.

KODULAR MEIN USE KARNE KE LIYE:
1. creator.kodular.io par apna AjmalCyberScanner project kholo.
2. Designer mein Palette ke search box mein Web Viewer search karo.
3. Web Viewer ko Screen1 par add karo aur Width/Height ko Fill parent set karo.
4. Assets/Media section mein index.html upload karo.
5. Web Viewer ka Home URL local asset path set karna Kodular version ke mutabiq ho sakta hai; agar page blank aaye to screenshot bhejo, main next step bataunga.

IMPORTANT:
Yeh ZIP HTML interface/demo hai — ready APK ya native Kodular .aia project nahi hai.
Wi-Fi aur Bluetooth buttons information/demo dikhate hain; ye all-device scanner, hacking tool, ya remote-control feature nahi hain. Real Android Wi-Fi/Bluetooth features ke liye Android permissions aur native implementation chahiye. Sirf apne devices/networks ya permission wale systems par test karein.
